export const API_BASE_URL = "http://localhost:5000"; // Leave empty to rely on proxy from package.json

export const fetchWithAuth = async (endpoint, options = {}) => {
    try {
        const token = localStorage.getItem("token");
        const headers = {
            "Content-Type": "application/json",
            ...options.headers,
        };

        if (token) {
            headers.Authorization = `Bearer ${token}`;
        }

        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers,
            credentials: "include",
        });

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem("token");
                window.location.href = "/login";
            }
            console.error("[API] HTTP error:", response.status, response.statusText);
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        return response.json();
    } catch (error) {
        console.error("[API] Error in fetchWithAuth:", error.message, { endpoint, options });
        throw error;
    }
};

// Fetch user's packs
export const fetchMyPacks = async () => {
    return fetchWithAuth("/api/packs/mypacks", {
        method: "GET",
    });
};

// Fetch user profile data
export const fetchUserProfile = async () => {
    return fetchWithAuth("/api/users/me", {
        method: "GET",
    });
};

// Fetch user collection (cards and packs)
export const fetchUserCollection = async (userId) => {
    try {
        const response = await fetchWithAuth(`/api/users/${userId}/collection`, {
            method: "GET",
        });
        console.log("[API] Fetched User Collection:", response);
        return response;
    } catch (error) {
        console.error("[API] Error fetching user collection:", error.message);
        throw error;
    }
};

// Fetch all cards recursively with pagination support
export const fetchCards = async ({ search = "", rarity = "", sort = "", page = 1, limit = 50 }) => {
    const queryParams = new URLSearchParams({
        search,
        rarity,
        sort,
        page,
        limit,
    });

    try {
        const response = await fetchWithAuth(`/api/cards?${queryParams.toString()}`, {
            method: "GET",
        });

        if (response.cards?.length === limit) {
            const nextPageData = await fetchCards({
                search,
                rarity,
                sort,
                page: page + 1,
                limit,
            });

            return {
                cards: [...response.cards, ...nextPageData.cards],
                totalCards: nextPageData.totalCards || response.totalCards,
            };
        }

        console.log(`[API] Fetched Cards from Page ${page}:`, response.cards);
        return response;
    } catch (error) {
        console.error("[API] Error fetching cards:", error.message);
        throw error;
    }
};

// Award a pack for first login
export const awardFirstLoginPack = async () => {
    return fetchWithAuth("/api/packs/firstlogin", {
        method: "POST",
    });
};

// Redeem channel points for a pack
export const redeemChannelPointsPack = async () => {
    return fetchWithAuth("/api/packs/redeem", {
        method: "POST",
    });
};

// Fetch user subscriptions
export const fetchUserSubscriptions = async () => {
    return fetchWithAuth("/api/users/subscriptions", {
        method: "GET",
    });
};

// Handle gifted subscriptions
export const handleGiftedSubscription = async (giftCount) => {
    return fetchWithAuth("/api/packs/gift", {
        method: "POST",
        body: JSON.stringify({ giftCount }),
    });
};

// Fetch featured cards for the logged-in user
export const fetchFeaturedCards = async () => {
    try {
        const response = await fetchWithAuth("/api/users/featured-cards", { method: "GET" });
        console.log("[API] Fetched Featured Cards:", response);
        return response;
    } catch (error) {
        console.error("[API] Error fetching featured cards:", error.message);
        throw error;
    }
};

// Update the featured cards for the logged-in user
export const updateFeaturedCards = async (featuredCards) => {
    try {
        const response = await fetchWithAuth("/api/users/featured-cards", {
            method: "PUT",
            body: JSON.stringify({ featuredCards }),
        });
        console.log("[API] Updated Featured Cards:", response);
        return response;
    } catch (error) {
        console.error("[API] Error updating featured cards:", error.message);
        throw error;
    }
};

// Create a new trade
export const createTrade = async ({ senderId, recipientId, offeredItems, requestedItems }) => {
    try {
        const response = await fetchWithAuth("/api/trades", {
            method: "POST",
            body: JSON.stringify({ senderId, recipientId, offeredItems, requestedItems }),
        });
        console.log("[API] Trade created successfully:", response);
        return response;
    } catch (error) {
        console.error("[API] Error creating trade:", error.message);
        throw error;
    }
};

// Fetch trades (incoming and outgoing)
export const fetchTrades = async (userId) => {
    try {
        const response = await fetchWithAuth(`/api/trades/${userId}`, {
            method: "GET",
        });
        console.log("[API] Fetched Trades:", response);
        return response;
    } catch (error) {
        console.error("[API] Error fetching trades:", error.message);
        throw error;
    }
};

// Update trade status (accept, reject)
export const updateTradeStatus = async (tradeId, status) => {
    try {
        const response = await fetchWithAuth(`/api/trades/${tradeId}`, {
            method: "PUT",
            body: JSON.stringify({ status }),
        });
        console.log("[API] Trade status updated:", response);
        return response;
    } catch (error) {
        console.error("[API] Error updating trade status:", error.message);
        throw error;
    }
};

// Search for users by username
export const searchUsers = async (query) => {
    try {
        const response = await fetchWithAuth(`/api/users/search?query=${query}`, {
            method: "GET",
        });
        console.log("[API] User search results:", response);
        return response;
    } catch (error) {
        console.error("[API] Error searching users:", error.message);
        throw error;
    }
};
