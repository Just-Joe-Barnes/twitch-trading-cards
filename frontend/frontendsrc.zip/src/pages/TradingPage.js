import React, { useState, useEffect } from "react";
import {
    fetchTrades,
    createTrade,
    updateTradeStatus,
    searchUsers,
    fetchWithAuth,
} from "../utils/api";
import "../styles/TradingPage.css";

const TradingPage = ({ userId }) => {
    const [activeTab, setActiveTab] = useState("incoming"); // Default to "Incoming Trades"
    const [incomingTrades, setIncomingTrades] = useState([]);
    const [outgoingTrades, setOutgoingTrades] = useState([]);
    const [step, setStep] = useState(1); // Step in the trade creation flow
    const [newTrade, setNewTrade] = useState({
        recipient: "",
        offeredItems: [],
        requestedItems: [],
    });
    const [searchQuery, setSearchQuery] = useState("");
    const [userSuggestions, setUserSuggestions] = useState([]);
    const [collection, setCollection] = useState({ cards: [], packs: 0 });

    // Fetch user's collection (cards and packs) on "New Trade" tab activation
    useEffect(() => {
        if (activeTab === "new" && step === 2 && userId) {
            fetchWithAuth(`/api/users/${userId}/collection`)
                .then((response) => {
                    setCollection({
                        cards: response.cards || [],
                        packs: response.packs || 0,
                    });
                })
                .catch((error) => {
                    console.error("Error fetching collection:", error);
                });
        }
    }, [activeTab, step, userId]);

    // Fetch trades on tab changes
    useEffect(() => {
        if ((activeTab === "incoming" || activeTab === "outgoing") && userId) {
            fetchTrades(userId)
                .then((response) => {
                    const { incoming, outgoing } = response;
                    setIncomingTrades(incoming || []);
                    setOutgoingTrades(outgoing || []);
                })
                .catch((error) => console.error("Error fetching trades:", error));
        }
    }, [activeTab, userId]);

    // Fetch user suggestions
    useEffect(() => {
        if (searchQuery.length > 1) {
            searchUsers(searchQuery)
                .then((results) => setUserSuggestions(results))
                .catch((error) => console.error("Error fetching user suggestions:", error));
        } else {
            setUserSuggestions([]);
        }
    }, [searchQuery]);

    // Handle user selection
    const handleUserSelect = (username) => {
        setNewTrade((prev) => ({ ...prev, recipient: username }));
        setSearchQuery("");
        setUserSuggestions([]);
        setStep(2); // Move to the next step: item selection
    };

    // Handle item selection for Offered/Requested Items
    const toggleItemSelection = (itemId, itemType, field) => {
        setNewTrade((prev) => {
            const isSelected = prev[field].find((item) => item.itemId === itemId);
            const updatedField = isSelected
                ? prev[field].filter((item) => item.itemId !== itemId)
                : [...prev[field], { itemId, itemType }];
            return {
                ...prev,
                [field]: updatedField,
            };
        });
    };

    const handleCreateTrade = () => {
        createTrade(newTrade)
            .then(() => {
                setNewTrade({ recipient: "", offeredItems: [], requestedItems: [] });
                setActiveTab("outgoing");
                setStep(1); // Reset to the first step
            })
            .catch((error) => console.error("Error creating trade:", error));
    };

    return (
        <div className="trading-page">
            <div className="tabs">
                <button onClick={() => setActiveTab("incoming")}>Incoming Trades</button>
                <button onClick={() => setActiveTab("outgoing")}>Outgoing Trades</button>
                <button onClick={() => {
                    setActiveTab("new");
                    setStep(1); // Reset to the first step
                }}>
                    New Trade
                </button>
            </div>
            <div className="content">
                {activeTab === "incoming" && (
                    <div className="incoming-trades">
                        <h2>Incoming Trades</h2>
                        {incomingTrades.map((trade) => (
                            <div key={trade._id} className="trade-item">
                                <p>From: {trade.senderId.username}</p>
                                <p>Offered Items: {JSON.stringify(trade.offeredItems)}</p>
                                <p>Requested Items: {JSON.stringify(trade.requestedItems)}</p>
                                <button onClick={() => updateTradeStatus(trade._id, "Accepted")}>Accept</button>
                                <button onClick={() => updateTradeStatus(trade._id, "Rejected")}>Reject</button>
                            </div>
                        ))}
                    </div>
                )}
                {activeTab === "outgoing" && (
                    <div className="outgoing-trades">
                        <h2>Outgoing Trades</h2>
                        {outgoingTrades.map((trade) => (
                            <div key={trade._id} className="trade-item">
                                <p>To: {trade.recipientId.username}</p>
                                <p>Offered Items: {JSON.stringify(trade.offeredItems)}</p>
                                <p>Requested Items: {JSON.stringify(trade.requestedItems)}</p>
                                <p>Status: {trade.status}</p>
                            </div>
                        ))}
                    </div>
                )}
                {activeTab === "new" && (
                    <div className="new-trade">
                        <h2>Create a New Trade</h2>
                        {step === 1 && (
                            <div className="user-search">
                                <input
                                    type="text"
                                    placeholder="Search for a recipient"
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                />
                                {userSuggestions.length > 0 && (
                                    <ul className="user-suggestions">
                                        {userSuggestions.map((user) => (
                                            <li key={user._id} onClick={() => handleUserSelect(user.username)}>
                                                {user.username}
                                            </li>
                                        ))}
                                    </ul>
                                )}
                            </div>
                        )}
                        {step === 2 && (
                            <>
                                <div className="item-select">
                                    <h3>Offered Items</h3>
                                    <div className="item-grid">
                                        {collection.cards.map((card) => (
                                            <div
                                                key={card._id}
                                                className={`item-card ${newTrade.offeredItems.find((item) => item.itemId === card._id) ? "selected" : ""}`}
                                                onClick={() => toggleItemSelection(card._id, "card", "offeredItems")}
                                            >
                                                <p>{card.name}</p>
                                                <p>Rarity: {card.rarity}</p>
                                            </div>
                                        ))}
                                        {collection.packs > 0 && (
                                            <div
                                                className={`item-card ${newTrade.offeredItems.find((item) => item.itemType === "pack") ? "selected" : ""}`}
                                                onClick={() => toggleItemSelection("pack", "pack", "offeredItems")}
                                            >
                                                <p>{collection.packs} Packs</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <div className="item-select">
                                    <h3>Requested Items</h3>
                                    <div className="item-grid">
                                        {collection.cards.map((card) => (
                                            <div
                                                key={card._id}
                                                className={`item-card ${newTrade.requestedItems.find((item) => item.itemId === card._id) ? "selected" : ""}`}
                                                onClick={() => toggleItemSelection(card._id, "card", "requestedItems")}
                                            >
                                                <p>{card.name}</p>
                                                <p>Rarity: {card.rarity}</p>
                                            </div>
                                        ))}
                                        <div
                                            className={`item-card ${newTrade.requestedItems.find((item) => item.itemType === "pack") ? "selected" : ""}`}
                                            onClick={() => toggleItemSelection("pack", "pack", "requestedItems")}
                                        >
                                            <p>Packs</p>
                                        </div>
                                    </div>
                                </div>
                                <button onClick={handleCreateTrade}>Send Trade Request</button>
                            </>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default TradingPage;
