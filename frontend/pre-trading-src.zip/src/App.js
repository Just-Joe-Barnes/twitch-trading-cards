import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import CollectionPage from './pages/CollectionPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import Navbar from './components/Navbar';
import ProfilePage from './pages/ProfilePage';

const App = () => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const handleTokenFromURL = () => {
            // Extract token from URL
            const params = new URLSearchParams(window.location.search);
            const token = params.get('token');

            if (token) {
                console.log('[App.js] Token received from URL:', token);
                localStorage.setItem('token', token); // Store the token in localStorage
                window.history.replaceState({}, document.title, '/dashboard'); // Remove token from URL
            }
        };

        const fetchUserData = async () => {
            const token = localStorage.getItem('token');
            console.log('[App.js] Token found:', token); // Debugging

            if (!token) {
                console.warn('[App.js] No token found, redirecting to login...');
                setLoading(false);
                return;
            }

            try {
                const response = await fetch('http://localhost:5000/api/auth/validate', {
                    method: 'POST',
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });

                if (!response.ok) {
                    throw new Error(`Token validation failed with status ${response.status}`);
                }

                const data = await response.json();
                console.log('[App.js] User validated:', data); // Debugging
                setUser(data);
            } catch (error) {
                console.error('[App.js] Token validation error:', error.message);
                localStorage.removeItem('token'); // Clear invalid token
                setUser(null);
            } finally {
                setLoading(false);
            }
        };

        handleTokenFromURL();
        fetchUserData();
    }, []);

    if (loading) {
        return <div>Loading...</div>; // Show a loading message or spinner
    }

    return (
        <Router>
            {/* Pass isAdmin to Navbar */}
            {user && <Navbar isAdmin={user?.isAdmin} />}
            <Routes>
                <Route path="/login" element={<LoginPage />} />
                <Route
                    path="/dashboard"
                    element={user ? <DashboardPage user={user} /> : <Navigate to="/login" />}
                />
                {/* Dynamic route for viewing a user's collection */}
                <Route
                    path="/collection/:username"
                    element={<CollectionPage />} // View another user's collection
                />
                {/* Default route for the logged-in user's collection */}
                <Route
                    path="/collection"
                    element={user ? <CollectionPage user={user} /> : <Navigate to="/login" />}
                />
                <Route
                    path="/admin-dashboard"
                    element={
                        user?.isAdmin ? <AdminDashboardPage user={user} /> : <Navigate to="/login" />
                    }
                />
                <Route
                    path="/profile/:username"
                    element={<ProfilePage />} // Dynamic username profile page
                />
                <Route path="/" element={<Navigate to="/dashboard" />} />
                <Route path="*" element={<Navigate to="/login" />} />
            </Routes>
        </Router>
    );
};

export default App;
