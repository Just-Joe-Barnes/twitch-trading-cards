import React, { useEffect, useState } from 'react';
import { fetchWithAuth } from '../utils/api';
import BaseCard from '../components/BaseCard';
import { useNavigate } from 'react-router-dom';
import '../styles/AdminDashboardPage.css';

const AdminDashboardPage = ({ user }) => {
    const navigate = useNavigate();
    const [usersWithPacks, setUsersWithPacks] = useState([]);
    const [selectedUser, setSelectedUser] = useState(null);
    const [loading, setLoading] = useState(false);
    const [openedCards, setOpenedCards] = useState([]);
    const [revealedCards, setRevealedCards] = useState([]);
    const [isOpeningAnimation, setIsOpeningAnimation] = useState(false);

    const cardRarities = [
        { rarity: 'Basic', color: '#a0a0a0', maxMint: 1000 },
        { rarity: 'Common', color: '#78c2ad', maxMint: 800 },
        { rarity: 'Standard', color: '#4a90e2', maxMint: 600 },
        { rarity: 'Uncommon', color: '#9068be', maxMint: 400 },
        { rarity: 'Rare', color: '#e5a228', maxMint: 300 },
        { rarity: 'Epic', color: '#ff4500', maxMint: 200 },
        { rarity: 'Legendary', color: '#72f1fc', maxMint: 100 },
        { rarity: 'Mythic', color: 'hotpink', maxMint: 50 },
        { rarity: 'Unique', color: 'black', maxMint: 10 },
        { rarity: 'Divine', color: 'white', maxMint: 1 },
    ];

    useEffect(() => {
        if (!user?.isAdmin) {
            console.warn('Access denied: Admins only.');
            navigate('/login');
            return;
        }

        const fetchUsersWithPacks = async () => {
            try {
                setLoading(true);
                const data = await fetchWithAuth('/api/packs/usersWithPacks');
                setUsersWithPacks(data.users || []);
            } catch (error) {
                console.error('Error fetching users with unopened packs:', error.message);
            } finally {
                setLoading(false);
            }
        };

        fetchUsersWithPacks();
    }, [user, navigate]);

    const openPackForUser = async () => {
        if (!selectedUser) return;

        try {
            setLoading(true);
            setIsOpeningAnimation(true);

            const response = await fetchWithAuth(`/api/packs/admin/openPacksForUser/${selectedUser._id}`, {
                method: 'POST',
            });

            const { newCards } = response;
            setOpenedCards(newCards);
            setRevealedCards(Array(newCards.length).fill(false));

            setUsersWithPacks((prev) =>
                prev.map((user) =>
                    user._id === selectedUser._id ? { ...user, packs: user.packs - 1 } : user
                )
            );
        } catch (error) {
            console.error('Error opening pack for user:', error.message);
            setIsOpeningAnimation(false);
        } finally {
            setLoading(false);
        }
    };

    const handleVideoEnd = () => {
        openedCards.forEach((_, index) => {
            setTimeout(() => {
                setRevealedCards((prev) => {
                    const updated = [...prev];
                    updated[index] = true;
                    return updated;
                });
            }, index * 1000);
        });

        setIsOpeningAnimation(false);
    };

    const toggleUserSelection = (user) => {
        setSelectedUser((prev) => (prev?._id === user._id ? null : user));
    };

    return (
        <div className="dashboard-container">
            {isOpeningAnimation && (
                <div className="pack-opening-overlay">
                    <video
                        className="pack-opening-video"
                        src="/animations/packopening.mp4"
                        autoPlay
                        playsInline
                        controls={false}
                        onEnded={handleVideoEnd}
                    />
                </div>
            )}

            <div className="grid-container">
                {/* Users with Packs Section */}
                <div className="users-with-packs">
                    <h2>Users with Packs</h2>
                    <table className="users-table">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Unopened Packs</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {usersWithPacks.map((user) => (
                                <tr
                                    key={user._id}
                                    className={selectedUser?._id === user._id ? 'selected' : ''}
                                    onClick={() => toggleUserSelection(user)}
                                >
                                    <td>{user.username}</td>
                                    <td>{user.packs}</td>
                                    <td>{user.packs > 0 ? 'Available' : 'No packs'}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* Open Pack Section */}
                <div className="selected-user-section">
                    {selectedUser && (
                        <>
                            <h2>Open Pack for {selectedUser.username}</h2>
                            <button
                                onClick={openPackForUser}
                                disabled={loading || isOpeningAnimation || selectedUser.packs <= 0}
                            >
                                {loading ? 'Opening...' : 'Open Pack'}
                            </button>
                        </>
                    )}
                </div>

                {/* Card Rarity Key Section */}
                <div className="card-rarity-key">
                    <h2>Card Rarity Key</h2>
                    <ul>
                        {cardRarities.map((rarity) => (
                            <li key={rarity.rarity}>
                                <span
                                    className="color-box"
                                    style={{
                                        backgroundColor: rarity.color,
                                    }}
                                ></span>
                                <span className="text">
                                    {rarity.rarity} - {rarity.maxMint === 1 ? `#1` : `#/${rarity.maxMint}`}
                                </span>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Opened Cards Section */}
                <div className="opened-cards">
                    <h2>Opened Cards</h2>
                    <div className="cards-container">
                        {openedCards.map((card, index) => (
                            <div
                                key={index}
                                className={`card-wrapper ${revealedCards[index] ? 'fade-in' : 'hidden'}`}
                            >
                                <BaseCard
                                    name={card.name}
                                    image={card.imageUrl}
                                    description={card.flavorText}
                                    rarity={card.rarity}
                                    mintNumber={card.mintNumber}
                                />
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboardPage;
