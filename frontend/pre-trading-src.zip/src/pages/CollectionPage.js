import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'; // Import useParams to get the username from the URL
import { fetchCards, fetchFeaturedCards, updateFeaturedCards, fetchUserProfile } from '../utils/api';
import BaseCard from '../components/BaseCard';
import '../styles/CollectionPage.css';
import { rarities } from '../constants/rarities';

const CollectionPage = () => {
    const { username: collectionOwner } = useParams(); // Get the collection owner's username from the URL
    const [loggedInUser, setLoggedInUser] = useState(null); // Store the logged-in user's information
    const [allCards, setAllCards] = useState([]);
    const [filteredCards, setFilteredCards] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [cardsPerPage] = useState(20);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [rarity, setRarity] = useState('');
    const [sort, setSort] = useState('');
    const [order, setOrder] = useState('asc');
    const [selectedFeatured, setSelectedFeatured] = useState(Array(4).fill(null));
    const [isEditingFeatured, setIsEditingFeatured] = useState(false);
    const [backupFeatured, setBackupFeatured] = useState([]);

    // Fetch the logged-in user's information
    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const profile = await fetchUserProfile();
                setLoggedInUser(profile.username);
            } catch (error) {
                console.error('Error fetching user profile:', error);
            }
        };

        fetchProfile();
    }, []);

    // Fetch cards and featured cards
    useEffect(() => {
        const fetchCollection = async () => {
            try {
                setLoading(true);
                const data = await fetchCards({ username: collectionOwner || loggedInUser });
                if (data.cards) {
                    setAllCards(data.cards);
                    setFilteredCards(data.cards);
                }
            } catch (error) {
                console.error('Error fetching cards:', error);
            } finally {
                setLoading(false);
            }
        };

        const fetchCurrentFeatured = async () => {
            try {
                const { featuredCards } = await fetchFeaturedCards();
                const preloadedFeatured = Array(4).fill(null);
                featuredCards.forEach((card, index) => {
                    if (index < 4) preloadedFeatured[index] = card;
                });
                setSelectedFeatured(preloadedFeatured);
            } catch (error) {
                console.error('Error fetching featured cards:', error);
            }
        };

        fetchCollection();
        if (!collectionOwner || collectionOwner === loggedInUser) {
            fetchCurrentFeatured();
        }
    }, [collectionOwner, loggedInUser]);

    // Filter and sort cards
    useEffect(() => {
        let filtered = [...allCards];

        if (search) {
            filtered = filtered.filter((card) =>
                card.name.toLowerCase().includes(search.toLowerCase())
            );
        }

        if (rarity) {
            filtered = filtered.filter(
                (card) =>
                    card.rarity.trim().toLowerCase() === rarity.trim().toLowerCase()
            );
        }

        if (sort) {
            filtered.sort((a, b) => {
                if (sort === 'mintNumber') {
                    return order === 'asc'
                        ? parseInt(a.mintNumber, 10) - parseInt(b.mintNumber, 10)
                        : parseInt(b.mintNumber, 10) - parseInt(a.mintNumber, 10);
                } else if (sort === 'name') {
                    return order === 'asc'
                        ? a.name.localeCompare(b.name)
                        : b.name.localeCompare(a.name);
                } else if (sort === 'rarity') {
                    const rarityA = rarities.findIndex(
                        (r) => r.name.toLowerCase() === a.rarity.toLowerCase()
                    );
                    const rarityB = rarities.findIndex(
                        (r) => r.name.toLowerCase() === b.rarity.toLowerCase()
                    );
                    return order === 'asc' ? rarityA - rarityB : rarityB - rarityA;
                }
                return 0;
            });
        }

        setFilteredCards(filtered);
        setCurrentPage(1);
    }, [allCards, search, rarity, sort, order]);

    const indexOfLastCard = currentPage * cardsPerPage;
    const indexOfFirstCard = indexOfLastCard - cardsPerPage;
    const currentCards = filteredCards.slice(indexOfFirstCard, indexOfLastCard);

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    const onDragStart = (event, card) => {
        event.dataTransfer.setData('card', JSON.stringify(card));
    };

    const onDrop = (event, index) => {
        const card = JSON.parse(event.dataTransfer.getData('card'));
        const updatedFeatured = [...selectedFeatured];
        updatedFeatured[index] = card;
        setSelectedFeatured(updatedFeatured);
    };

    const onDragOver = (event) => {
        event.preventDefault();
    };

    const removeCardFromSlot = (index) => {
        const updatedFeatured = [...selectedFeatured];
        updatedFeatured[index] = null;
        setSelectedFeatured(updatedFeatured);
    };

    const saveFeaturedCards = async () => {
        try {
            const filteredFeatured = selectedFeatured.filter((card) => card !== null);
            await updateFeaturedCards(filteredFeatured);
            alert('Featured cards updated successfully!');
            setIsEditingFeatured(false);
        } catch (error) {
            console.error('Error updating featured cards:', error);
            alert('Failed to update featured cards.');
        }
    };

    const cancelEditingFeatured = () => {
        setSelectedFeatured(backupFeatured);
        setIsEditingFeatured(false);
    };

    const startEditingFeatured = () => {
        setBackupFeatured([...selectedFeatured]);
        setIsEditingFeatured(true);
    };

    return (
        <div className="collection-page">
            <h1>
                {collectionOwner === loggedInUser
                    ? 'Your Collection'
                    : `${collectionOwner}'s Collection`}
            </h1>

            <div className="filters">
                <input
                    type="text"
                    placeholder="Search by card name..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                <select value={rarity} onChange={(e) => setRarity(e.target.value)}>
                    <option value="">All Rarities</option>
                    {rarities.map((r) => (
                        <option key={r.name} value={r.name.toLowerCase()}>
                            {r.name}
                        </option>
                    ))}
                </select>
                <select value={sort} onChange={(e) => setSort(e.target.value)}>
                    <option value="">Sort By</option>
                    <option value="name">Name</option>
                    <option value="mintNumber">Mint Number</option>
                    <option value="rarity">Rarity</option>
                </select>
                <select value={order} onChange={(e) => setOrder(e.target.value)}>
                    <option value="asc">Ascending</option>
                    <option value="desc">Descending</option>
                </select>
            </div>

            {/* Only show "Edit Featured Cards" if viewing own collection */}
            {!isEditingFeatured && loggedInUser === collectionOwner ? (
                <button
                    className="toggle-featured-button"
                    onClick={startEditingFeatured}
                >
                    Edit Featured Cards
                </button>
            ) : isEditingFeatured ? (
                <div className="featured-slots">
                    <h2>Edit Featured Cards</h2>
                    <p>Drag cards into slots below to feature them:</p>
                    <div className="slots-container">
                        {Array(4)
                            .fill(null)
                            .map((_, index) => (
                                <div
                                    key={index}
                                    className="slot"
                                    onDragOver={onDragOver}
                                    onDrop={(event) => onDrop(event, index)}
                                    onDoubleClick={() => removeCardFromSlot(index)}
                                >
                                    {selectedFeatured[index] ? (
                                        <BaseCard
                                            name={selectedFeatured[index].name}
                                            image={selectedFeatured[index].imageUrl}
                                            rarity={selectedFeatured[index].rarity}
                                            description={selectedFeatured[index].flavorText}
                                            mintNumber={selectedFeatured[index].mintNumber}
                                            maxMint={
                                                rarities.find(
                                                    (r) =>
                                                        r.name.toLowerCase() ===
                                                        selectedFeatured[index].rarity.toLowerCase()
                                                )?.totalCopies || '???'
                                            }
                                        />
                                    ) : (
                                        <p>Empty Slot</p>
                                    )}
                                </div>
                            ))}
                    </div>
                    <button className="save-featured-button" onClick={saveFeaturedCards}>
                        Save Featured Cards
                    </button>
                    <button
                        className="toggle-featured-button"
                        onClick={cancelEditingFeatured}
                    >
                        Cancel
                    </button>
                </div>
            ) : null}

            <div className="cards-container">
                {loading ? (
                    <p>Loading...</p>
                ) : currentCards.length > 0 ? (
                    currentCards.map((card) => (
                        <div
                            key={card._id}
                            draggable
                            onDragStart={(event) => onDragStart(event, card)}
                        >
                            <BaseCard
                                name={card.name}
                                image={card.imageUrl}
                                rarity={card.rarity}
                                description={card.flavorText}
                                mintNumber={card.mintNumber}
                                maxMint={
                                    rarities.find(
                                        (r) => r.name.toLowerCase() === card.rarity.toLowerCase()
                                    )?.totalCopies || '???'
                                }
                            />
                        </div>
                    ))
                ) : (
                    <p>No cards found.</p>
                )}
            </div>

            <div className="pagination">
                {Array.from(
                    { length: Math.ceil(filteredCards.length / cardsPerPage) },
                    (_, index) => (
                        <button
                            key={index + 1}
                            className={currentPage === index + 1 ? 'active' : ''}
                            onClick={() => paginate(index + 1)}
                        >
                            {index + 1}
                        </button>
                    )
                )}
            </div>
        </div>
    );
};

export default CollectionPage;
