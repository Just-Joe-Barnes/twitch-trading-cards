import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import BaseCard from '../components/BaseCard';
import '../styles/ProfilePage.css';
import { fetchFeaturedCards, fetchUserProfile } from '../utils/api';

const ProfilePage = () => {
    const [featuredCards, setFeaturedCards] = useState([]);
    const [loading, setLoading] = useState(true);
    const [username, setUsername] = useState('');
    const navigate = useNavigate(); // Navigation hook

    // Fetch user profile data
    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const profile = await fetchUserProfile(); // Fetch user profile
                setUsername(profile.username || 'User'); // Set username, fallback to "User"
            } catch (error) {
                console.error('Error fetching user profile:', error);
            }
        };

        fetchProfile();
    }, []);

    // Fetch featured cards
    useEffect(() => {
        const fetchFeatured = async () => {
            try {
                setLoading(true);
                const { featuredCards } = await fetchFeaturedCards();
                setFeaturedCards(featuredCards);
            } catch (error) {
                console.error('Error fetching featured cards:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchFeatured();
    }, []);

    // Handle "View Collection" button click
    const handleViewCollection = () => {
        navigate(`/collection/${username}`); // Navigate to the user's collection page
    };

    return (
        <div className="profile-page">
            <div className="welcome-box">
                <h1>{username}'s Profile</h1>
            </div>
            <div className="featured-cards-container">
                <h2>Featured Cards</h2>
                {loading ? (
                    <p>Loading...</p>
                ) : featuredCards.length > 0 ? (
                    <div className="featured-cards">
                        {featuredCards.map((card) => (
                            <BaseCard
                                key={card._id}
                                name={card.name}
                                image={card.imageUrl}
                                rarity={card.rarity}
                                description={card.flavorText}
                                mintNumber={card.mintNumber}
                                maxMint={
                                    card?.maxMint ||
                                    card.rarities?.find((r) => r.name.toLowerCase() === card.rarity.toLowerCase())
                                        ?.totalCopies || '???'
                                }
                            />
                        ))}
                    </div>
                ) : (
                    <p>Set your featured cards on your collection page</p>
                )}
            </div>
            {/* Add View Collection Button */}
            <div className="view-collection-button-container">
                <button className="view-collection-button" onClick={handleViewCollection}>
                    View {username}'s Full Collection
                </button>
            </div>
        </div>
    );
};

export default ProfilePage;
