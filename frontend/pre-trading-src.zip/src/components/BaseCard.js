import React, { useRef } from 'react';
import '../styles/CardComponent.css';
import { rarities } from '../constants/rarities'; // Adjust the path if necessary

const BaseCard = ({
    name,
    image,
    description,
    rarity = 'common', // Default to 'common' if rarity is undefined,
    mintNumber,
    draggable,
    onDragStart,
    onDoubleClick,
}) => {
    const cardRef = useRef(null);

    // Lower rarity glare
    const glareRef = useRef(null);

    // Rare
    const holoRef = useRef(null);

    // Epic swirl (but NO swirl texture in CSS)
    const epicShineRef = useRef(null);

    // Legendary
    const legendaryRef = useRef(null);
    const legendarySparkleRef = useRef(null);
    const legendaryGradientMaskRef = useRef(null);

    // Cursor-responsive gradient
    const cursorGradientRef = useRef(null);

    // Holo V
    const holoVRef = useRef(null);

    // Mythic cursor gradient
    const mythicCursorGradientRef = useRef(null);

    // Unique neo-rain
    const neoRainRef = useRef(null);

    // Divine card artwork
    const divineArtworkRef = useRef(null);

    const handleMouseMove = (e) => {
        const card = cardRef.current;
        if (!card) return;

        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // Subtle 3D tilt
        const halfW = rect.width / 2;
        const halfH = rect.height / 2;
        const rotateX = -((y - halfH) / 10);
        const rotateY = ((x - halfW) / 10);
        card.style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;

        // Glare (lower rarities)
        if (glareRef.current && ["common", "standard", "uncommon"].includes(rarity.toLowerCase())) {
            const glareX = ((x / rect.width) * 100).toFixed(2);
            const glareY = ((y / rect.height) * 100).toFixed(2);
            glareRef.current.style.transform = `translate(-50%, -50%) scale(1.2)`;
            glareRef.current.style.opacity = '0.6';
            glareRef.current.style.background =
                `radial-gradient(circle at ${glareX}% ${glareY}%, 
          var(--glare-color, rgba(255,255,255,0.5)), rgba(255,255,255,0))`;
        }

        // Rare
        if (holoRef.current && rarity.toLowerCase() === 'rare') {
            const gradientX = (x / rect.width) * 100;
            const gradientY = (y / rect.height) * 100;
            holoRef.current.style.backgroundPosition = `${gradientX}% ${gradientY}%`;
            holoRef.current.style.opacity = '0.8';
        }

        // EPIC swirl (NO swirl texture in CSS)
        if (rarity.toLowerCase() === 'epic') {
            if (epicShineRef.current) {
                const distX = x - halfW;
                const distY = y - halfH;
                const hyp = Math.sqrt(distX * distX + distY * distY) / 50;
                const clamp = (val, min, max) => Math.min(Math.max(val, min), max);
                const clampedHyp = clamp(hyp, 0, 1);

                // Custom props for parallax
                card.style.setProperty('--mx', `${40 - rotateY * 5}%`);
                card.style.setProperty('--my', `${5 + rotateX}%`);
                card.style.setProperty('--posx', `${(x / rect.width) * 100}%`);
                card.style.setProperty('--posy', `${(y / rect.height) * 100}%`);
                card.style.setProperty('--hyp', clampedHyp);

                // Show epic swirl overlay
                epicShineRef.current.style.opacity = '0.8'; // or '1'
            }
        }

        // Legendary
        if (legendaryRef.current && rarity.toLowerCase() === 'legendary') {
            const gradientX = (x / rect.width) * 100;
            const gradientY = (y / rect.height) * 100;
            legendaryRef.current.style.backgroundPosition = `${gradientX}% ${gradientY}%`;
            legendaryRef.current.style.opacity = '1';

            if (legendarySparkleRef.current) {
                legendarySparkleRef.current.style.backgroundPosition = `${gradientX}% ${gradientY}%`;
                legendarySparkleRef.current.style.opacity = '0.6';
            }

            if (legendaryGradientMaskRef.current) {
                legendaryGradientMaskRef.current.style.backgroundPosition = `${gradientX}% ${gradientY}%`;
            }
        }

        // Cursor-responsive gradient
        if (cursorGradientRef.current) {
            cursorGradientRef.current.style.background = `radial-gradient(circle at ${x}px ${y}px, rgba(0,255,255,0.3), transparent)`;
        }

        // Holo V
        if (holoVRef.current) {
            const gradientX = (x / rect.width) * 100;
            const gradientY = (y / rect.height) * 100;
            holoVRef.current.style.backgroundPosition = `${gradientX}% ${gradientY}%`;
            holoVRef.current.style.opacity = '0.8';
        }

        // Mythic cursor gradient
        if (mythicCursorGradientRef.current) {
            mythicCursorGradientRef.current.style.setProperty('--cursor-x', `${x}px`);
            mythicCursorGradientRef.current.style.setProperty('--cursor-y', `${y}px`);
        }

        // Divine parallax effect
        if (divineArtworkRef.current && rarity.toLowerCase() === 'divine') {
            const moveX = (x - halfW) / 20; // Adjust the multiplier for desired effect
            const moveY = (y - halfH) / 20; // Adjust the multiplier for desired effect
            divineArtworkRef.current.style.transform = `translate(${moveX}px, ${moveY}px)`;
        }
    };

    const handleMouseLeave = () => {
        const card = cardRef.current;
        if (card) {
            card.style.transform = 'perspective(700px) rotateX(0deg) rotateY(0deg)';
            card.style.removeProperty('--mx');
            card.style.removeProperty('--my');
            card.style.removeProperty('--posx');
            card.style.removeProperty('--posy');
            card.style.removeProperty('--hyp');
        }

        if (glareRef.current) {
            glareRef.current.style.opacity = '0';
            glareRef.current.style.transform = 'translate(-50%, -50%) scale(0)';
        }

        if (holoRef.current) {
            holoRef.current.style.opacity = '0';
        }

        // Turn off epic swirl
        if (epicShineRef.current) {
            epicShineRef.current.style.opacity = '0';
        }

        // Legendary
        if (legendaryRef.current) {
            legendaryRef.current.style.opacity = '0';
        }

        if (legendarySparkleRef.current) {
            legendarySparkleRef.current.style.opacity = '0';
            legendarySparkleRef.current.style.backgroundPosition = 'center';
        }

        if (legendaryGradientMaskRef.current) {
            legendaryGradientMaskRef.current.style.backgroundPosition = 'center';
        }

        // Cursor-responsive gradient
        if (cursorGradientRef.current) {
            cursorGradientRef.current.style.background = 'none';
        }

        // Holo V
        if (holoVRef.current) {
            holoVRef.current.style.opacity = '0';
        }

        // Mythic cursor gradient
        if (mythicCursorGradientRef.current) {
            mythicCursorGradientRef.current.style.backgroundPosition = 'center';
        }

        // Unique neo-rain
        if (neoRainRef.current) {
            neoRainRef.current.style.opacity = '0';
        }

        // Reset Divine parallax effect
        if (divineArtworkRef.current) {
            divineArtworkRef.current.style.transform = 'translate(0, 0)';
        }
    };

    return (
        <div
            ref={cardRef}
            className={`card-container ${rarity.toLowerCase()}`} // Applies rarity-based class
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            draggable={draggable} // Enables drag-and-drop if true
            onDragStart={(e) => draggable && onDragStart && onDragStart(e)} // Handles drag start
            onDoubleClick={onDoubleClick} // Handles double-click to remove
            style={rarity.toLowerCase() === 'divine' ? { backgroundImage: `url(${image})` } : {}}
        >
            {/* Cursor-responsive gradient */}
            {rarity.toLowerCase() === 'legendary' && (
                <div ref={cursorGradientRef} className="cursor-gradient" />
            )}

            {/* Glare */}
            {["basic", "common", "standard", "uncommon"].includes(rarity.toLowerCase()) && (
                <div ref={glareRef} className="card-glare" />
            )}

            {/* Rare */}
            {rarity.toLowerCase() === 'rare' && (
                <div ref={holoRef} className="holographic-overlay" />
            )}

            {/* EPIC swirl (no swirl texture in CSS) */}
            {rarity.toLowerCase() === 'epic' && (
                <div ref={epicShineRef} className="epic-shine" />
            )}

            {/* Legendary */}
            {rarity.toLowerCase() === 'legendary' && (
                <>
                    <div ref={legendaryGradientMaskRef} className="legendary-gradient-mask" />
                    <div ref={legendaryRef} className="legendary-overlay" />
                    <div ref={legendarySparkleRef} className="legendary-sparkle" />
                </>
            )}

            {/* Holo V */}
            {rarity.toLowerCase() === 'holo-v' && (
                <div ref={holoVRef} className="holo-v" />
            )}

            {/* Mythic */}
            {rarity.toLowerCase() === 'mythic' && (
                <>
                    <div className="mythic-particles" />
                    <div className="mythic-holographic-overlay" />
                    <div className="mythic-tint" />
                </>
            )}

            {/* Unique */}
            {rarity.toLowerCase() === 'unique' && (
                <div ref={neoRainRef} className="neo-rain" />
            )}

            <div className="card-border">
                {rarity.toLowerCase() === 'divine' ? (
                    <div className="card-header">
                        <div className="card-name">{name}</div>
                        <div className="card-mint">
                            <span className="mint-number">
                                {mintNumber} / {rarities?.find((r) => r.name.toLowerCase() === rarity.toLowerCase())?.totalCopies || '???'}
                            </span>
                        </div>
                    </div>
                ) : (
                    <>
                        <div className="card-name">{name}</div>
                        <div
                            className="card-artwork"
                            ref={rarity.toLowerCase() === 'divine' ? divineArtworkRef : null}
                        >
                            <img src={image} alt={name} />
                        </div>
                        {description && <div className="card-description">{description}</div>}
                        <div className="card-mint">
                            <span className="mint-number">
                                {mintNumber} / {rarities?.find((r) => r.name.toLowerCase() === rarity.toLowerCase())?.totalCopies || '???'}
                            </span>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default BaseCard;
