const express = require('express');
const { getCollection } = require('../controllers/collectionController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', protect, getCollection);

module.exports = router;
