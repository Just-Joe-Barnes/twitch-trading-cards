const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

const protect = async (req, res, next) => {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1]; // Extract token
            console.log('[AUTH VALIDATE] Token received:', token);

            // Decode and verify the token
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            console.log('[AUTH VALIDATE] Decoded token:', decoded);

            // Find the user by `twitchId` instead of `_id`
            req.user = await User.findOne({ twitchId: decoded.id }).select('-password');
            if (!req.user) {
                console.error('[AUTH VALIDATE] User not found for Twitch ID:', decoded.id);
                return res.status(401).json({ message: 'User not found' });
            }

            // Populate `req.userId` and other data for downstream usage
            req.userId = req.user._id.toString();
            req.userTwitchId = req.user.twitchId; // Optional, if Twitch ID is used later
            req.userIsAdmin = req.user.isAdmin; // Add admin status to request
            console.log('[AUTH VALIDATE] User validated:', req.user.username);

            next(); // Proceed to the next middleware
        } catch (error) {
            console.error('[AUTH VALIDATE] Token error:', error.message);
            return res.status(401).json({ message: 'Not authorized, token failed' });
        }
    } else {
        return res.status(401).json({ message: 'Not authorized, no token' });
    }
};

const adminOnly = (req, res, next) => {
    if (req.user?.isAdmin) { // Check the `isAdmin` property from `req.user`
        console.log('[ADMIN CHECK] Admin access granted for user:', req.user.username);
        next(); // Proceed to the next middleware
    } else {
        console.error('[ADMIN CHECK] Access denied for user:', req.user.username);
        return res.status(403).json({ message: 'Access denied: Admins only' });
    }
};

module.exports = { protect, adminOnly };
