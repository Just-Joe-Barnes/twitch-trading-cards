const User = require('../models/userModel');

// Get logged-in user's profile
const getUserProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user._id).select(
            'username email isAdmin openedPacks featuredCards'
        );

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json(user);
    } catch (error) {
        console.error('Error fetching user profile:', error.message);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get user's featured cards
const getFeaturedCards = async (req, res) => {
    try {
        const user = await User.findById(req.user._id).select('featuredCards');
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.status(200).json({ featuredCards: user.featuredCards });
    } catch (error) {
        console.error('[getFeaturedCards] Error:', error.message);
        res.status(500).json({ message: 'Failed to fetch featured cards' });
    }
};

// Update user's featured cards
const updateFeaturedCards = async (req, res) => {
    try {
        const { featuredCards } = req.body;

        // Validate the input
        if (!featuredCards || !Array.isArray(featuredCards) || featuredCards.length > 4) {
            return res
                .status(400)
                .json({ message: 'Invalid featured cards. Provide up to 4 cards.' });
        }

        const user = await User.findById(req.user._id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        user.featuredCards = featuredCards;
        await user.save();

        res.status(200).json({ message: 'Featured cards updated successfully', featuredCards: user.featuredCards });
    } catch (error) {
        console.error('[updateFeaturedCards] Error:', error.message);
        res.status(500).json({ message: 'Failed to update featured cards' });
    }
};

// Search for users by username
const searchUsers = async (req, res) => {
    const { query } = req.query;

    try {
        if (!query) {
            return res.status(400).json({ message: 'Search query is required' });
        }

        // Search for usernames matching the query (partial match, case-insensitive)
        const users = await User.find({ username: { $regex: query, $options: 'i' } }).select(
            'username'
        ); // Only return the username field

        res.status(200).json(users);
    } catch (error) {
        console.error('[User Search] Error:', error.message);
        res.status(500).json({ message: 'Server error while searching for users' });
    }
};

// Module exports
module.exports = {
    getUserProfile,
    getFeaturedCards,
    updateFeaturedCards,
    searchUsers,
};
