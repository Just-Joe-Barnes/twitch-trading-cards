const Trade = require('../models/tradeModel');

// Create a new trade
const createTrade = async (req, res) => {
    try {
        const { senderId, recipientId, offeredItems, requestedItems } = req.body;

        // Validate sender's ownership of offered items
        const userInventory = await Collection.findOne({ userId: senderId });

        if (!userInventory) {
            return res.status(400).json({ success: false, message: 'Sender has no inventory' });
        }

        const invalidItems = offeredItems.filter(
            (item) => !userInventory.items.some((invItem) => invItem.itemId.equals(item.itemId))
        );

        if (invalidItems.length > 0) {
            return res.status(400).json({ success: false, message: 'Sender does not own all offered items' });
        }

        // Create the trade
        const newTrade = await Trade.create({
            senderId,
            recipientId,
            offeredItems,
            requestedItems,
        });

        res.status(201).json({ success: true, trade: newTrade });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to create trade', error: error.message });
    }
};

// Fetch trades (incoming and outgoing)
const getTrades = async (req, res) => {
    try {
        const { userId } = req.params; // The user's ID from the route parameter
        const { status } = req.query; // Optional status filter (e.g., Pending, Accepted, Rejected)

        const filter = {
            $or: [
                { senderId: userId }, // User is the sender
                { recipientId: userId }, // User is the recipient
            ],
        };

        // Add status filter if provided
        if (status) {
            filter.status = status;
        }

        const trades = await Trade.find(filter)
            .populate('senderId', 'username') // Include sender's username
            .populate('recipientId', 'username') // Include recipient's username
            .sort({ createdAt: -1 }); // Sort trades by most recent

        res.status(200).json({ success: true, trades });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to fetch trades', error: error.message });
    }
};

// Update trade status
const updateTradeStatus = async (req, res) => {
    try {
        const { tradeId } = req.params;
        const { status } = req.body;

        const updatedTrade = await Trade.findByIdAndUpdate(tradeId, { status, updatedAt: Date.now() }, { new: true });

        if (!updatedTrade) {
            return res.status(404).json({ success: false, message: 'Trade not found' });
        }

        res.status(200).json({ success: true, trade: updatedTrade });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to update trade status', error: error.message });
    }
};

// Cancel Trade
const cancelTrade = async (req, res) => {
    try {
        const { tradeId } = req.params;

        const deletedTrade = await Trade.findOneAndDelete({
            _id: tradeId,
            status: 'Pending', // Only allow canceling pending trades
        });

        if (!deletedTrade) {
            return res.status(404).json({ success: false, message: 'Trade not found or already processed' });
        }

        res.status(200).json({ success: true, message: 'Trade canceled successfully', trade: deletedTrade });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to cancel trade', error: error.message });
    }
};

module.exports = {
    createTrade,
    getTrades,
    updateTradeStatus,
    cancelTrade,
};
