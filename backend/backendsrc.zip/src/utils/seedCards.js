const Card = require('../models/cardModel');

const seedDatabase = async () => {
    const rarities = [
        { name: 'Basic', totalCopies: 1000 },
        { name: 'Common', totalCopies: 800 },
        { name: 'Standard', totalCopies: 600 },
        { name: 'Uncommon', totalCopies: 400 },
        { name: 'Rare', totalCopies: 300 },
        { name: 'Epic', totalCopies: 200 },
        { name: 'Legendary', totalCopies: 100 },
        { name: 'Mythic', totalCopies: 50 },
        { name: 'Unique', totalCopies: 10 },
        { name: 'Divine', totalCopies: 1 },
    ];

    const cards = [
        {
            name: 'Dragon',
            imageUrl: '/images/cards/dragon.png',
            flavorText: 'A mythical beast that rules the skies.',
            rarities: rarities.map((rarity) => ({
                rarity: rarity.name,
                totalCopies: rarity.totalCopies, // Total mintable copies
                remainingCopies: rarity.totalCopies, // Copies available for minting
                availableMintNumbers: Array.from(
                    { length: rarity.totalCopies },
                    (_, i) => i + 1 // Generate mint numbers from 1 to totalCopies
                ),
            })),
        },
        {
            name: 'Ned',
            imageUrl: '/images/cards/phoenix.png',
            flavorText: 'The quirky adventurer.',
            rarities: rarities.map((rarity) => ({
                rarity: rarity.name,
                totalCopies: rarity.totalCopies, // Total mintable copies
                remainingCopies: rarity.totalCopies, // Copies available for minting
                availableMintNumbers: Array.from(
                    { length: rarity.totalCopies },
                    (_, i) => i + 1 // Generate mint numbers from 1 to totalCopies
                ),
            })),
        },
    ];

    try {
        // Clear the existing cards in the database
        await Card.deleteMany({});
        console.log('Existing cards cleared.');

        // Insert the new cards into the database
        await Card.insertMany(cards);
        console.log('Cards seeded successfully.');
    } catch (error) {
        console.error('Error seeding database:', error.message);
    }
};

module.exports = seedDatabase;
