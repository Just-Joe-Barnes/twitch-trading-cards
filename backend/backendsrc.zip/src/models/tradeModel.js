const mongoose = require('mongoose');

const tradeSchema = new mongoose.Schema({
    senderId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    recipientId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    offeredItems: {
        type: [
            {
                itemId: { type: mongoose.Schema.Types.ObjectId, required: true },
                itemType: { type: String, enum: ['Card', 'Pack'], required: true },
            },
        ],
        required: true,
    },
    requestedItems: {
        type: [
            {
                itemId: { type: mongoose.Schema.Types.ObjectId, required: true },
                itemType: { type: String, enum: ['Card', 'Pack'], required: true },
            },
        ],
        required: true,
    },
    status: {
        type: String,
        enum: ['Pending', 'Accepted', 'Rejected'],
        default: 'Pending',
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
    updatedAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Trade', tradeSchema);
