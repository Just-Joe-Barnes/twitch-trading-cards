const express = require('express');
const {
    createTrade,
    getTrades,
    updateTradeStatus,
    cancelTrade,
} = require('../controllers/tradeController');

const router = express.Router();

// Create a new trade
router.post('/', createTrade);

// Get trades for a user (with optional status filter)
router.get('/:userId', getTrades);

// Update trade status (accept, reject)
router.put('/:tradeId', updateTradeStatus);

// Cancel a trade
router.delete('/:tradeId', cancelTrade);

module.exports = router;
